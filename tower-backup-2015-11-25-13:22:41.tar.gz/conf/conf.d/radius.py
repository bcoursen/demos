###############################################################################
# RADIUS AUTHENTICATION SETTINGS
###############################################################################

# Ansible Tower can be configured to centrally use Radius as a source for
# authentication information.

# Radius server settings (skipped when RADIUS_SERVER is blank).
RADIUS_SERVER = ''
RADIUS_PORT = 1812
RADIUS_SECRET = ''
