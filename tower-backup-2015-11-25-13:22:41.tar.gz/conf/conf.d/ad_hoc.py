# Uncomment the lines below to change the list of allowed modules for running
# ad hoc commands.

#AD_HOC_COMMANDS = [
#    'command',
#    'shell',
#    'yum',
#    'apt',
#    'apt_key',
#    'apt_repository',
#    'apt_rpm',
#    'service',
#    'group',
#    'user',
#    'mount',
#    'ping',
#    'selinux',
#    'setup',
#    'win_ping',
#    'win_service',
#    'win_updates',
#    'win_group',
#    'win_user',
#]
