# HTTP headers and meta keys to search to determine remote host name or IP. Add
# additional items to this list, such as "HTTP_X_FORWARDED_FOR", if behind a
# reverse proxy.
# Note: The headers will be searched in order and the first found remote host
# name or IP will be used.
# 
# In the below example 8.8.8.7 would be the chosen IP address.
# X-Forwarded-For: 8.8.8.7, 192.168.2.1, 127.0.0.1
# Host: 127.0.0.1
# REMOTE_HOST_HEADERS = ['HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR', 'REMOTE_HOST']

REMOTE_HOST_HEADERS = ['REMOTE_ADDR', 'REMOTE_HOST']
