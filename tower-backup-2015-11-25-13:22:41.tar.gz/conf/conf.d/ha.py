
# The system UUID, as captured by Ansible.
SYSTEM_UUID = 'b49df33e-21b9-4450-ab5e-cb1bbb349d2c'
